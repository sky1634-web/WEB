<?php
require "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=test1.local',
        'root', '' );

session_start();
